Execute on ubuntu 16.04. 

To execute the HW:
    1. key "make"
    2. key "sudo ./serfork"
    3. open your browser and go to url "0.0.0.0"
    4. select a file
    5. recieve the file in folder upload.
